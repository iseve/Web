# My Resume

[预览链接](https://woshiqiang1.github.io/resume/)


## Development

```
$ npm install
$ npm install -g gulp
$ gulp
```
